﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    internal class F5
    {
        public static void pattern(int n)
        {
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(j + " ");
                }
                Console.WriteLine();
            }
        }
        public static void Main(String[] args)
        {
            int n;
            Console.WriteLine("enter n value");
            n = int.Parse(Console.ReadLine());
            pattern(n);
        }
    }
}
