﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    internal class _4
    {
        
        public static void Main(String[] args)
        {
            Random random = new Random();
            int RandomNumber = random.Next(1, 100);
            Console.WriteLine("Guess the number between 1 and 100: in 5 attempts");
            int attempts = 5;
            bool correct = false;
            for (int i = 0; i < attempts; i++)
            {
                int guess = Convert.ToInt32(Console.ReadLine());

                if (guess == RandomNumber)
                {
                    Console.WriteLine("You guessed the number");
                    correct = true;
                    break;
                }
                else if (guess < RandomNumber)
                {
                    Console.WriteLine("The number is greater than the guess");
                }
                else if (guess > RandomNumber)
                {
                    Console.WriteLine("The number is less than the guess");
                }
                else
                {
                    Console.WriteLine("Try again");
                }
            }
            if (!correct)
            {
                Console.WriteLine("You did not guess the number, the correct number is:" + RandomNumber);
            }
        }
    }
}
