﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    internal class S4
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of prime numbers you want to generate: ");
            int n = Convert.ToInt32(Console.ReadLine());

            int count = 0;
            int i = 2;
            while (count < n)
            {
                bool isPrime = true;
                for (int j = 2; j <= Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime)
                {
                    Console.WriteLine(i);
                    count++;
                }
                i++;
            }
            Console.WriteLine(
                "The first " + n + " prime numbers are generated successfully");
            Console.ReadLine();

        }
    }
}
