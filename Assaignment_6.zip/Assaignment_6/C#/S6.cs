﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assesment_6
{
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
    public class Enrollment
    {
        public int StudentID { get; set; }
        public string Course { get; set; }
    }

    internal class S6
    {
        static void Main(string[] args)
        {
            List<Student> students = new List<Student>
            {
                new Student { ID = 1, Name = "Sai" },
                new Student { ID = 2, Name = "Teja" },
                new Student { ID = 3, Name = "Itachi" }
            };


            List<Enrollment> enrollments = new List<Enrollment>
            {
                new Enrollment { StudentID = 1, Course = "Mathematics" },
                new Enrollment { StudentID = 1, Course = "Physics" },
                new Enrollment { StudentID = 2, Course = "Chemistry" },
                new Enrollment { StudentID = 3, Course = "Biology" },
                new Enrollment { StudentID = 3, Course = "Mathematics" }
            };

            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.ID equals enrollment.StudentID
                                 select new
                                 {
                                     StudentName = student.Name,
                                     CourseName = enrollment.Course
                                 }; 
            Console.WriteLine("Student Courses:");
            foreach (var sc in studentCourses)
            {
                Console.WriteLine($"Student: {sc.StudentName}, Course: {sc.CourseName}");
            }

        }
    }
}
