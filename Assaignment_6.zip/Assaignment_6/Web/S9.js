const Books = [
    { bookId: 1, Name: 'hellsparadise', Author: 'sai', Date: '2001/12/12' },
    { bookId: 2, Name: 'Onepiece', Author: 'sai', Date: '2001/12/12' },
    { bookId: 3, Name: 'Naruto', Author: 'sai', Date: '2001/12/12' },
];

function displayBooks(books) {
    for (let book of books) {
        console.log(`Id: ${book.bookId} Name: ${book.Name} Author: ${book.Author} Date: ${book.Date}`);
    }
}

displayBooks(Books);
